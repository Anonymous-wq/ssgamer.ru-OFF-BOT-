<?php 
class CartorderController extends Controller
{
public function actionConfirm()
{
$cart = UsualCart::listGoods();
if (empty ($cart)) {
throw new CHttpException(404,'Корзина пуста. Выберите товары для заказа');
}
$bill = Yii::app()->session['thecartorder'];

if (!$bill) {
throw new CHttpException(403,'Не заполнена форма оплаты');
}
$cart2 = self::_goodList($cart,$bill->cupon,$bill->email);
$this->render('confirm',array (
'model' =>$bill,
'goods' =>$cart2,
));
}
public function actionIndex()
{
if (Settings::item('usualCartOn')!=1) {
throw new CHttpException (404,'Извините, но корзина отключена');
}
$cart = UsualCart::listGoods();
if (empty ($cart)) {
throw new CHttpException(404,'Корзина пуста. Выберите товары для заказа');
}
$model = new Bill;
$model->unsetAttributes ();
$kind = UsualCart::checkKind();
if ($kind=='disk') {
$model->disk = TRUE;
}
$model->kind = $kind;

if(isset($_POST['Bill'])) {
$bbb = $_POST['Bill'];
$ballow = array ('email','uname','amail','cupon','surname','otchestvo','strana','gorod','region','street','comment','phone','postindex','address');
foreach ($bbb as $bbkey=>$one) {
if (!in_array ($bbkey,$ballow)) {
unset ($bbb[$bbkey]);
}
}
$model->attributes = $bbb;
if ($model->validate()) {
Yii::app()->session['thecartorder'] = $model;
$this->redirect (array('confirm'));
}
}else {
if (($kind=='disk') &&(Settings::item('phoneDisk')!=1)) {
$model->phone = 'нет';
}
if (($kind!='disk') &&(Settings::item('phoneEbook')!=1)) {
$model->phone = 'нет';
}
}
$this->render('index',array (
'model' =>$model,
'kind' =>$kind,
));
}
public function actionComplete () {
$cart = UsualCart::listGoods();
if (empty ($cart)) {
throw new CHttpException(404,'Корзина пуста. Выберите товары для заказа');
}
$bill = Yii::app()->session['thecartorder'];
if (!$bill) {
throw new CHttpException(403,'Не заполнена форма оплаты');
}
$cart2 = self::_goodList($cart,$bill->cupon);
$bill->id = NULL;
$bill->isNewRecord = TRUE;
$bill->createDate = time ();
$bill->payDate = 0;
$bill->status_id = Bill::BILL_WAITING;
$bill->ip = Yii::app()->request->userHostAddress;
$bill->way = base64_decode('');
$bill->kind = UsualCart::checkKind();
$bill->orderCount = count ($cart2);
$bill->postNumber = base64_decode('');
$bill->usdkurs = Settings::item('kursUsd');
$bill->eurkurs = Settings::item('kursEur');
$bill->uahkurs = Settings::item('kursUah');
$bill->valuta = 'rur';
$total = 0;
foreach ($cart2 as $one) {
$total += $one->rurcena;
}
$bill->sum = $total;
if (!$bill->save ()) {
throw new CHttpException(403,'Произошла неизвестная ошибка при формировании счёта. Пожалуйста, выпишите новый.');
}
$ord = new Order;

foreach ($cart2 as $good) {
$ord->id = NULL;
$ord->isNewRecord = TRUE;
$ord->bill_id = $bill->id;
$ord->good_id = $good->id;
$ord->createDate = $bill->createDate;
$ord->cena = $good->newprice;
$ord->valuta = $good->currency;
if (!$ord->save ()) {
throw new CHttpException(403,'Произошла неизвестная ошибка при формировании заказа. Пожалуйста, сделайте новый заказ');
}
}
Yii::app()->session['thecartorder'] = FALSE;
UsualCart::emptyCart();
$data = array (
'bill_id'   =>$bill->id,
'sum'       =>H::mysum($bill->sum).H::valuta($bill->valuta),
'status_link' =>Y::bu().'status/index/b/'.$bill->id.'/c/'.Bill::statusCrc ($bill->id),
);
Mail::letter ('bill_new',$bill->email,$bill->uname,$data);
$this->redirect (array('bill/index','bill_id' =>$bill->id,'hash' =>Bill::hashBill($bill->id)));
}
private static function _goodList ($cart,$kupon,$email = false) {
$nc = array ();
foreach ($cart as $good) {
$gd = Good::model()->findByPk ($good['id']);
if (!$gd) {
throw new CHttpException(404,'К сожалению, один из товаров, помещённых в корзину, не существует. Сформируйте Корзину заново.');
}
if (!empty ($kupon)) {
if (Cupon::valid ($kupon,$email)!=base64_decode('')) {
$gd->newprice = Cupon::goodCena ($kupon,$gd);
}
}else {
$gd->newprice = $gd->price;
}
$rurcena = (Valuta::conv($gd->newprice,$gd->currency));
$gd->rurcena = $rurcena['rur'];
$nc[] = $gd;
}
return $nc;
}
};