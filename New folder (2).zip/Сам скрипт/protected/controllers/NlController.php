<?php 
class NlController extends Controller
{
public function actionConfirm($b,$c)
{
if (!is_numeric ($b)) die ('Bad bill ID');
if (!preg_match ('/^[0-9a-z_]+$/',$c)) die ('Bad CRC');
if (Bill::nalozh2Crc($b)!=$c) {
die ('Bad CRC');
}
$bill = Bill::model()->findByPk ($b);
if (!$bill) die ('Счёт не найден');
if ($bill->status_id!='nalozh') {
throw new CHttpException (403,'Извините, но данный счёт уже был изменён ранее и не может быть повторно изменён');
}
$bill->status_id = 'nalozh_confirmed';
if (Settings::item('nalozhManual')==1) {
$bill->status_id = 'nalozh';
if (Settings::item('nalozhEmail')) {
$bill->comment = '[E-MAIL ПОДТВЕРЖДЁН '.date ('j.m.Y H:i:s').'] '.$bill->comment;
}
}
$bill->save (FALSE);

$dd = array (
'bill_id' =>$bill->id,
'status_link' =>Bill::statusLink ($b),
);
if (Settings::item('nalozhManual')!=1) {
if ($bill->curier) {
Mail::letter('kurier_confirmed',$bill->email,$bill->uname,$dd);
}else {
Mail::letter('nalozh_confirmed',$bill->email,$bill->uname,$dd);
}
}
$tocopy = array ('email','amail','cupon','surname','uname','otchestvo',
'strana','gorod','region','address','postindex','phone','comment','ip');
$d = array (
'bill_id' =>$bill->id,
'status_link' =>Bill::statusLink ($b),
'kupon' =>$bill->cupon,
);
foreach ($tocopy as $one) {
$d[$one] = $bill->$one;
}
$d['sum'] = H::mysum($bill->sum).H::valuta($bill->valuta);
$ord = base64_decode('');
$orders = $bill->orders;
foreach ($orders as $one) {
$ord.= ' ['.$one->good->id.'] '.$one->good->title."\r\n";
}
$d['orders'] = $ord;
$d['refid'] = $orders[0]->partner_id;
$d['admin_link'] = Y::bu().'admin/bill/view/id/'.$b;
if (Settings::item('nalozhManual')!=1) {
if ($bill->curier) {
Mail::sys ('admin_kurier_confirmed',$d);
}else {
Mail::sys ('admin_nalozh_confirmed',$d);
}
}
$g = $bill->orders[0]->good;
if ($g->csellOn) {
$this->redirect (Y::bu().'nl/special/b/'.$b.'/c/'.Bill::crossCrc ($b));
}else {
$this->redirect (Y::bu().'nl/confirmed/b/'.$b.'/c/'.Bill::nalozh3Crc ($b));
}
}
public function actionConfirmed($b,$c)
{
if (!is_numeric ($b)) die ('Bad bill ID');
if (!preg_match ('/^[0-9a-z_]+$/',$c)) die ('Bad CRC');
if (Bill::nalozh3Crc($b)!=$c) {
die ('Bad CRC');
}
$this->render('confirmed',array (
'slink' =>Bill::statusLink ($b),
));
}
public function actionIndex($b,$c)
{
if (!is_numeric ($b)) die ('Bad bill ID');
if (!preg_match ('/^[0-9a-z_]+$/',$c)) die ('Bad CRC');
if (Bill::nalozhCrc($b)!=$c) {
die ('Bad CRC');
}
$confirmLink = Y::bu().'nl/confirm/b/'.$b.'/c/'.Bill::nalozh2Crc ($b);
$bill = Bill::model()->findByPk ($b);
if (!$bill) die ('Счёт не найден');
if ($bill->status_id!='waiting') {
throw new CHttpException (403,'Извините, но данный счёт уже был изменён ранее, выпишите новый');
}
$bill->status_id = 'nalozh';
if (isset ($_POST['kurier'])) {
$bill->curier = 1;
}
$bill->save (FALSE);
if (!Settings::item('nalozhEmail')) {
$this->redirect ($confirmLink);
}
$dd = array (
'bill_id' =>$bill->id,
'sum' =>H::mysum($bill->sum).H::valuta($bill->valuta),
'status_link' =>Bill::statusLink ($b),
'nalozh_link' =>$confirmLink,
);
if ($bill->curier) {
Mail::letter('kurier_confirm',$bill->email,$bill->uname,$dd);
}else {
Mail::letter('nalozh_confirm',$bill->email,$bill->uname,$dd);
}
$tocopy = array ('email','amail','cupon','surname','uname','otchestvo',
'strana','gorod','region','address','postindex','phone','comment','ip');
$d = array (
'bill_id' =>$bill->id,
'status_link' =>Bill::statusLink ($b),
'kupon' =>$bill->cupon,
);
foreach ($tocopy as $one) {
$d[$one] = $bill->$one;
}
$d['sum'] = H::mysum($bill->sum).H::valuta($bill->valuta);
$ord = base64_decode('');
$orders = $bill->orders;
foreach ($orders as $one) {
$ord.= ' ['.$one->good->id.'] '.$one->good->title."\r\n";
}
$d['orders'] = $ord;
$d['refid'] = $orders[0]->partner_id;
$d['admin_link'] = Y::bu().'admin/bill/view/id/'.$b;
if ($bill->curier) {
Mail::sys ('admin_kurier_notconfirmed',$d);
}else {
Mail::sys ('admin_nalozh_notconfirmed',$d);
}
$this->render('index');
}
public function actionUp ($n)
{
if (!is_numeric ($n)) die ('Bad number');
$b = Yii::app()->session['crossB'];
if (!$b) die ('Извините, но Ваша сессия уже окончена - поэтому добавление более невозможно');
$g = Yii::app()->session['crossG'];
$g = Good::model ()->findByPk ($g);
$crc = Yii::app()->session['crossC'];
if (Bill::crossCrc($b)!= $crc) die ('Ошибка контрольной суммы');
if (($n == 1) &&($g->csellOn == 1)) 
{
$g2 = $g->csellGood;
Bill::cross ($g2,$b,$g->id);
}
if (($n == 2) &&(!empty ($g->csell2))) 
{
$g2 = $g->csell2g;
Bill::cross ($g2,$b,$g->id);
}
if (($n == 3) &&(!empty ($g->csell3))) 
{
$g2 = $g->csell3g;
Bill::cross ($g2,$b,$g->id);
}
$ok = FALSE;
$url = '/';
if ($n == 1) {
if (empty($g->csell2)) {
$ok = TRUE;
}else {
$url = $g->csell2;
}
}
if ($n == 2) {
if (empty($g->csell3)) {
$ok = TRUE;
}else {
$url = $g->csell3;
}
}
if ($n == 3) {
$ok = TRUE;
}
if ($ok) {
Yii::app()->session['crossB'] = FALSE;
Yii::app()->session['crossC'] = FALSE;
Yii::app()->session['crossG'] = FALSE;
if (!empty ($g->csellOk)) {
$this->redirect ($g->csellOk);
}else {
$this->render('ok',array (
'slink' =>Bill::statusLink ($b->id),
),FALSE,'order_cross_ok/'.($g->id));
}
}else {
$this->redirect ($url);
}
}
public function actionOk($b,$g,$c)
{
if (!is_numeric ($b)) die ('Bad bill ID');
if (!preg_match ('/^[0-9a-z_]+$/',$g)) die ('Bad good id');
if (!preg_match ('/^[0-9a-z_]+$/',$c)) die ('Bad CRC');
if (Bill::cross2Crc($b,$g)!=$c) {
die ('Bad CRC');
}
$gg = Good::model()->findByPk ($g);
$g2 = $gg->csellGood;
Bill::cross ($g2,$b,$gg->id);
Yii::app()->session['crossB'] = FALSE;
Yii::app()->session['crossC'] = FALSE;
Yii::app()->session['crossG'] = FALSE;
$this->render('ok',array (
'slink' =>Bill::statusLink ($b),
),FALSE,'order_cross_ok/'.$g);
}
public function actionSpecial($b,$c)
{
if (!is_numeric ($b)) die ('Bad bill ID');
if (!preg_match ('/^[0-9a-z_]+$/',$c)) die ('Bad CRC');
if (Bill::crossCrc($b)!=$c) {
die ('Bad CRC');
}
$bill = Bill::model()->findByPk ($b);
if (!$bill) die ('Счёт не найден');
$g = $bill->orders[0]->good;
if (!$g->csellOn) die ('Функция отключена для данного товара');
$ctext = $g->csellText;
Yii::app()->session['crossB'] = $b;
Yii::app()->session['crossC'] = Bill::crossCrc ($b);
Yii::app()->session['crossG'] = $g->id;
$curl = trim($ctext);
if (substr ($curl,0,7)=='http://') {
$this->redirect ($curl);
}else {
$this->render('special',array (
'okurl' =>Y::bu().'nl/ok/b/'.$b.'/g/'.$g->id.'/c/'.Bill::cross2crc ($b,$g->id),
'cross' =>$g->csellText,
),FALSE,'order_cross/'.$g->id);
}
}
};