<?php 
class MypageController extends Controller
{
public function actionIndex ($id)
{
if (!preg_match ('/[0-9a-z_]+/',$id)) die ('Page url error');
$p = Page::model ()->find (array (
'condition' =>'psevdo = :psevdo',
'params' =>array (
':psevdo' =>$id,
),
));
if (!$p) die ('Page not found');
if (!$p->visible) die ('Извините, но эта страничка недоступна к просмотру в данное время');

$this->layout = '//layouts/mypage';
if (strpos ($p->title,'||')!==false) {
$title2 = explode ('||',$p->title);
$p->title = trim ($title2[0]);
$name = trim ($title2[1]);
if (preg_match ('/^[a-z0-9A-Z]{1,100}$/',$name)) {
$this->layout = '//layouts/'.$name;
}
}
$this->pageTitle = $p->title;
$this->render ('/main/mpage',array ('data' =>$p->content));
}
};